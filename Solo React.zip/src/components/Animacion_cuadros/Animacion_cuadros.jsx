import React from 'react';
import './Animacion_cuadros.css';

export const Animacion_cuadros = () => {
  return (
    
      <div className="animacion" >
            <ul className="cuadros">
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    
            </ul>
    </div >
      
  )
}
